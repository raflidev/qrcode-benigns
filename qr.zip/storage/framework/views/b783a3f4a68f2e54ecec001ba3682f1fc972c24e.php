<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BENING'S | QR SCAN</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js','resources/js/users.js','resources/js/header.js']); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
</head>
<body>
    <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activePage' => 'qr']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
    <div class="content p-7 flex flex-col gap-8 ml-64 2xl:ml-80 2xl:gap-12 dark:bg-accent min-h-[calc(100vh-48px)] 2xl:min-h-[calc(100vh-56px)]  " >
        <?php if(Session::has('error')): ?>
            <div id="error" class="w-full px-5 bg-red-500 text-white py-3 rounded items-center">
                <?php echo e(Session::get('error')); ?>

                <div class="float-right" onclick="closePopup1()">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke-width="1.5" stroke="currentColor"
                        class="w-6 h-6  hover:rounded-full text-white hover:bg-red-800 hover:cursor-pointer">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <div id="success"
                class="success w-full px-5 bg-green-500 text-white py-3 rounded items-center">
                <?php echo e(Session::get('success')); ?>

                <div class="float-right" onclick="closePopup2()">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke-width="1.5" stroke="currentColor"
                        class="w-6 h-6  hover:rounded-full text-white hover:bg-green-800 hover:cursor-pointer">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
        <?php endif; ?>
        <div class="flex items-center justify-between">
            <h1 class="font-bold text-3xl 2xl:text-4xl dark:text-white ">
                QR SCAN
            </h1>
        </div>
        <div class="flex space-x-10">
          <div class="w-1/2">
            <div id="reader" width="100px" class=""></div>
          </div>
          <div class="w-1/2">
            <div>
              <span id="scanReq" class="font-bold text-xl">Silakan Scan QR Code</span>
              <div id="result" class="hidden space-y-4 ">
                  <div>
                      <span class="font-bold">Kode yang terscan</span>
                      <div id="resultQR" class="uppercase"></div>
                  </div>
                  <div id="resultMessage" class="text-red-500">
                      <span class="font-bold">Hasil :</span>
                      <div id="resultMessageText"></div>
                  </div>
                  <form class="hidden space-y-4" id="resultTrue" method="POST" action="<?php echo e(route('qr.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <input type="hidden" name="kodeunik" class="kodeunik" value="">
                    <input type="hidden" name="id_unik" class="id_unik" value="">
                    <div>
                        <span class="font-bold">Benefit</span>
                        <div id="benefit" class=""></div>
                    </div>
                    <div>
                        <span class="font-bold">Nama Customer</span>
                        <input type="text" id="nama_user" name="nama_user" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="Nama User">
                    </div>
                    <div>
                        <span class="font-bold">No HP</span>
                        <input type="text" id="no_hp" name="no_hp" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="0812931xxxxxx">
                    </div>
                    <div>
                        <span class="font-bold">Jenis Mitra</span>
                        <select type="text" id="jenis_mitra" name="jenis_mitra" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white">
                            <option value="Reseller">Reseller</option>
                            <option value="Agen">Agen</option>
                            <option value="Distributor">Distributor</option>
                        </select>
                    </div>
                    <div>
                        <button class="flex items-center gap-1 py-1.5  pl-2 pr-4 bg-gray-900/75 text-white rounded-lg" type="submit">
                            <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'add']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                            <span>Proses Kupon</span>
                        </button>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
    </div>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script>
        var lastResult, countResults = 0;
        function onScanSuccess(decodedText, decodedResult) {
            if (decodedText !== lastResult) {
                ++countResults;
                lastResult = decodedText;
                // Handle on success condition with the decoded message.
                console.log(`Scan result ${decodedText}`, decodedResult);

                getQR(decodedText);
                $('#result').removeClass('hidden');
                $('#scanReq').addClass('hidden');
            }
        }

        function getQR(id) {
            var param = id.split(',')
            console.log(id);
            $('#resultQR').text(param[1]);
            $('.kodeunik').val(param[1]);
            $('.id_unik').val(param[0]);
            $.get('/checkQR/'+id, function (data) {
                if(data.status != "error"){
                    $('#resultTrue').removeClass('hidden');
                    $('#resultMessage').removeClass('hidden');
                    $('#resultMessageText').text("Kupon dapat digunakan");
                    $('#resultMessage').removeClass('text-red-500');
                    $('#resultMessage').addClass('text-green-500');
                    $('#benefit').text(data.benefit);
                    $('#email').val(param[1]);
                }else{
                    $('#resultTrue').addClass('hidden');
                    $('#resultMessage').removeClass('hidden');
                    $('#resultMessage').removeClass('text-green-500');
                    $('#resultMessage').addClass('text-red-500');
                    $('#resultMessageText').text(data.message);
                }
            })
        }

        function onScanFailure(error) {
            //
        }

        let html5QrcodeScanner = new Html5QrcodeScanner(
            "reader", {
                fps: 10,
                qrbox: {
                    width: 250,
                    height: 250
                }
            },
            /* verbose= */
            false);
        html5QrcodeScanner.render(onScanSuccess, onScanFailure);
    </script>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script>
        function closePopup1() {
            document.getElementById('error').classList.add('hidden');
        }
        function closePopup2() {
            document.getElementById('success').classList.add('hidden');
        }
    </script>
</body>
</html>
<?php /**PATH C:\Users\rafli\Documents\DevLearn\project\qrbening2\resources\views/qrscan.blade.php ENDPATH**/ ?>