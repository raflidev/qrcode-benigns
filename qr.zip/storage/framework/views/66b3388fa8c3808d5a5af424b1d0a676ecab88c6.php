<?php
    $dateSplitted = explode(",",date("d,m,Y"));
    $currDay = substr(date("l"),0,3);
    $currDate = $dateSplitted[0];
    $currMonth = substr(DateTime::createFromFormat('!m', $dateSplitted[1])->format('F'),0,3);
    $currYear = $dateSplitted[2];
?>

<header class="h-12 flex justify-end items-center border-b-2 px-3 bg-gray-100 dark:bg-light-dark dark:border-dark 2xl:h-14">
    <div class="header-component flex ">
        <div class="utility relative pr-4 flex gap-5 items-center dark:text-white 2xl:gap-6">
            
            <button class="flex items-center" id="dark-mode-toggle">
                <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'dark-mode']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
            </button>
        </div>
        <div class="times flex gap-4 border-l pl-5 border-black/30 items-center dark:text-white dark:border-white 2xl:gap-6">
            
            <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'today']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
            <p class="date-time">
                <?php echo e($currDay); ?>, <?php echo e($currDate); ?> <?php echo e($currMonth); ?> <?php echo e($currYear); ?>

            </p>
        </div>
    </div>
</header>
<?php /**PATH C:\Users\rafli\Documents\DevLearn\project\qrbening2\resources\views/components/header.blade.php ENDPATH**/ ?>