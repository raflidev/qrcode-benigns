
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BENING'S | Generate Coupons</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>
<body>
    <?php $__currentLoopData = $kupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="">
            <?php if($data['kodeunik'] == "proyellowLaser"): ?>
                <?php for($i=0;$i < $data['max_use'];$i++): ?>
                    <div class="relative">
                        <div class="absolute bottom-2 left-16">
                            <?php echo QrCode::size(70)->generate(uniqid().','.$data['kodeunik'].','.$data['expired_at']); ?>

                        </div>
                        <div class="absolute top-2 left-16 text-sm bg-black text-white">
                            Expired at :  <?php echo e(\Carbon\Carbon::parse($data['expired_at'])->format('d M Y')); ?>

                        </div>
                      <img src="/images/Proyellow.png" class="w-full" alt="" srcset="">
                    </div>
                <?php endfor; ?>
            <?php else: ?>
                <?php for($i=0;$i < $data['max_use'];$i++): ?>
                    <div class="relative">
                        <div class="absolute bottom-2 left-16">
                            <?php echo QrCode::size(70)->generate(uniqid().','.$data['kodeunik'].','.$data['expired_at']); ?>

                        </div>
                        <div class="absolute top-2 left-16 text-sm bg-black text-white">
                            Expired at : <?php echo e(\Carbon\Carbon::parse($data['expired_at'])->format('d M Y')); ?>

                        </div>
                      <img src="/images/QSwitched.png" class="w-full" alt="" srcset="">
                    </div>
                <?php endfor; ?>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        window.print();
    </script>
</body>
</html>
<?php /**PATH C:\Users\rafli\Documents\DevLearn\project\qrbening2\resources\views/coupons_generate.blade.php ENDPATH**/ ?>