<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BENING'S | Transaction</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js','resources/js/transaction.js','resources/js/header.js']); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
</head>
<body>
    <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['activePage' => 'transactions']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
    <div class="content p-7 flex flex-col gap-8 ml-64 2xl:ml-80 2xl:gap-12 dark:bg-accent min-h-[calc(100vh-48px)] 2xl:min-h-[calc(100vh-56px)]  " >
        <?php if(Session::has('error')): ?>
            <div id="error" class="w-full px-5 bg-red-500 text-white py-3 rounded items-center">
                <?php echo e(Session::get('error')); ?>

                <div class="float-right" onclick="closePopup1()">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke-width="1.5" stroke="currentColor"
                        class="w-6 h-6  hover:rounded-full text-white hover:bg-red-800 hover:cursor-pointer">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            <div id="success"
                class="success w-full px-5 bg-green-500 text-white py-3 rounded items-center">
                <?php echo e(Session::get('success')); ?>

                <div class="float-right" onclick="closePopup2()">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke-width="1.5" stroke="currentColor"
                        class="w-6 h-6  hover:rounded-full text-white hover:bg-green-800 hover:cursor-pointer">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
        <?php endif; ?>
        <div class="flex items-center justify-between">
            <h1 class="font-bold text-3xl 2xl:text-4xl dark:text-white ">
                Transactions
            </h1>
            <?php if(Auth::user()->role == 'superadmin'): ?>
            <div class="flex space-x-3">
                <a href="<?php echo e(route('transaction.excel')); ?>" target="_blank" class="flex items-center gap-1 py-1.5  pl-2 pr-4 bg-green-900/75 text-white rounded-lg">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'add']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                    <span>Export Excel</span>
                </a>
                <button class="openModalAdd flex items-center gap-1 py-1.5  pl-2 pr-4 bg-gray-900/75 text-white rounded-lg" type="button" data-modal-toggle="add-user-modal">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'add']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                    <span>Add Transaction</span>
                </button>
            </div>
            <?php endif; ?>
        </div>

        <table id="transactionTable" class="dark:bg-light-dark dark:text-white">
            <thead class="">
                <tr class="">
                    <th class="w-4">No</th>
                    <th>ID Transaksi</th>
                    <th>Kode Unik Kupon</th>
                    <th>Jenis Mitra</th>
                    <th>Nama Admin</th>
                    <th>FO</th>
                    <th>Nama Customer</th>
                    <th>No HP</th>
                    <th>Dibuat pada</th>
                    <th>Terakhir di update</th>
                    <?php if(Auth::user()->role == 'superadmin'): ?>
                    <th class="w-56 2xl:w-44">Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $no= 1; ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                        <td><?php echo e($no); ?></td>
                        <td><?php echo e($product['id_unik']); ?></td>
                        <td><?php echo e($product['kodeunik']); ?></td>
                        <td><?php echo e($product['jenis_mitra']); ?></td>
                        <td><?php echo e($product['name']); ?></td>
                        <td><?php echo e($product['outlet']); ?></td>
                        <td><?php echo e($product['nama_user']); ?></td>
                        <td><?php echo e($product['no_hp']); ?></td>
                        <td><?php echo e(date('d F Y h:m:s', strtotime($product['created_at']))); ?></td>
                        <td><?php echo e(date('d F Y h:m:s', strtotime($product['updated_at']))); ?></td>
                        <?php if(Auth::user()->role == 'superadmin'): ?>
                        <td>
                            <button id="deleteTransaction" data-id="<?php echo e($product['id']); ?>" class="deleteTransaction w-24 h-9 border border-red-400/50 hover:border-red-400 text-red-400 bg-transparent hover:bg-red-200/30 hover:text-red-600 rounded-lg text-sm py-1.5 pr-2 pl-1 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white">
                                <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'delete']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                                <span class="">Remove</span>
                            </button>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php $no++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo $__env->make('modal.transaction.delete-transaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('modal.transaction.add-transaction', ['kupon' => $kupon], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script>
        function closePopup1() {
            document.getElementById('error').classList.add('hidden');
        }
        function closePopup2() {
            document.getElementById('success').classList.add('hidden');
        }
    </script>
</body>
</html>
<?php /**PATH C:\Users\rafli\Documents\DevLearn\project\qrbening2\resources\views/transactions.blade.php ENDPATH**/ ?>