<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['activePage'=>'dashboard']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['activePage'=>'dashboard']); ?>
<?php foreach (array_filter((['activePage'=>'dashboard']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="sidebar fixed top-0 left-0 w-64 bg-light-dark dark:bg-dark h-full flex flex-col gap-3 px-3 py-6 2xl:w-80 2xl:px-4 2xl:py-8 2xl:gap-6">
    <div class="identity text-white h-24 flex  justify-center items-center font-bold text-2xl 2xl:gap-3 gap-2 2xl:text-3xl">
        
        <span>Benings</span>
    </div>
    <div class="navigation text-white flex flex-col justify-between h-full ">
        <div class="navigation-component flex flex-col gap-2 2xl:gap-3">
            <div class="navElement group flex gap-3 h-12 p-4 2xl:gap-4  rounded-xl hover:bg-dark items-center cursor-pointer <?php echo e($activePage === 'dashboard' ? "bg-black/40" : ""); ?>" id="dashboard">
                
                <div class="w-4 h-4 flex justify-center items-center  group-hover:opacity-100 <?php echo e($activePage === 'dashboard' ? "opacity-100" : "opacity-50"); ?>">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'home']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                </div>
                <p class=" 2xl:text-lg group-hover:text-white/100 <?php echo e($activePage === 'dashboard' ? "text-white/100 	" : "text-white/50"); ?>">
                    Dashboard
                </p>
            </div>
            <?php if(Auth::user()->role == 'superadmin'): ?>
            <div class="navElement group flex gap-3 2xl:gap-4 h-12 p-4 rounded-xl hover:bg-black/30  items-center cursor-pointer <?php echo e($activePage === 'users' ? "bg-black/40" : ""); ?>" id="users">
                
                <div class="w-4 h-4 flex justify-center items-center group-hover:opacity-100 <?php echo e($activePage === 'users' ? "opacity-100" : "opacity-50"); ?>">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                </div>
                <p class="2xl:text-lg group-hover:text-white/100 <?php echo e($activePage === 'users' ? "text-white/100" : "text-white/50"); ?>">
                    Users
                </p>
            </div>
            <?php endif; ?>
            <div class="navElement group flex gap-3 2xl:gap-4 h-12 p-4 rounded-xl hover:bg-black/30   items-center cursor-pointer <?php echo e($activePage === 'coupons' ? "bg-black/40 " : ""); ?>" id="coupons">
                
                <div class="w-4 h-4 flex justify-center items-center group-hover:opacity-100 <?php echo e($activePage === 'coupons' ? "opacity-100 " : "opacity-50"); ?>">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'voucher']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                </div>
                <p class="2xl:text-lg group-hover:text-white/100 <?php echo e($activePage === 'coupons' ? "text-white/100 " : "text-white/50"); ?>">
                    Coupons
                </p>
            </div>
            <div class="navElement group flex gap-3 2xl:gap-4 h-12 p-4 rounded-xl hover:bg-black/30   items-center cursor-pointer <?php echo e($activePage === 'transactions' ? "bg-black/40 " : ""); ?>" id="transactions">
                
                <div class="w-4 h-4 flex justify-center items-center group-hover:opacity-100 <?php echo e($activePage === 'transactions' ? "opacity-100 " : "opacity-50"); ?>">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'cash']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                </div>
                <p class="2xl:text-lg group-hover:text-white/100 <?php echo e($activePage === 'transactions' ? "text-white/100 " : "text-white/50"); ?>">
                    Transactions
                </p>
            </div>
            <div class="navElement group flex gap-3 2xl:gap-4 h-12 p-4 rounded-xl hover:bg-black/30   items-center cursor-pointer <?php echo e($activePage === 'qr' ? "bg-black/40 " : ""); ?>" id="qr">
                
                <div class="w-4 h-4 flex justify-center items-center group-hover:opacity-100 <?php echo e($activePage === 'qr' ? "opacity-100 " : "opacity-50"); ?>">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'camera']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                </div>
                <p class="2xl:text-lg group-hover:text-white/100 <?php echo e($activePage === 'qr' ? "text-white/100 " : "text-white/50"); ?>">
                    QR Scan
                </p>
            </div>
        </div>
        <div class="navigation-action">
            <div class="navElement group flex gap-3 2xl:gap-4 h-12 p-4 rounded-xl hover:bg-black/40 bg-black/20  items-center cursor-pointer" id=''>
                
                <div class="w-4 h-4 flex justify-center items-center opacity-100 group:opacity-100">
                    <?php if (isset($component)) { $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea = $component; } ?>
<?php $component = App\View\Components\Mysvg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mysvg'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Mysvg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea)): ?>
<?php $component = $__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea; ?>
<?php unset($__componentOriginal5565d7e21bf1fccfa849521c2b6135e01c6955ea); ?>
<?php endif; ?>
                </div>
                <form action="<?php echo e(route('user.logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('POST'); ?>
                    <button type="submit" class="2xl:text-lg text-white/100 group-hover:text-white/100">
                        Log Out
                    </button>
                </form>
            </div>
        </div>
    </div>

</div>

<script>
    const list = document.querySelectorAll('.navigation-component .navElement')

    list.forEach(element => {
        const id = element.id
        if (id === <?php echo e($activePage); ?>){
            setActive(element)
        }
    })
    list.forEach(element => {
        element.addEventListener('click',(e) => {
            e.preventDefault()
            window.location.href = element.id;
        })
    });
</script>
<?php /**PATH C:\Users\rafli\Documents\DevLearn\project\qrbening2\resources\views/components/sidebar.blade.php ENDPATH**/ ?>